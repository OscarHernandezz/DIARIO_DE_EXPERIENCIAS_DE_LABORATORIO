﻿using System;

namespace L13_OAHB_1088321
{
    class Program
    {
        static void Main(string[] args)
        {
            Datos dt = new Datos();
            dt.eval();
            dt.Imprimir();
        }
        class Datos
        {
            private string[] nombres;
            private int[] edades;
            public int edad = 0;

            public void eval()
            {
                nombres = new string[5];
                edades = new int[5];
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("Ingrese el nombre de la persona");
                    string linea;
                    linea = Console.ReadLine();
                    nombres[i] = linea;
                    Console.WriteLine("Ingrese la edad de la persona");
                    string edad;
                    edad = Console.ReadLine();
                    edades[i] = int.Parse(edad);
                }
                
            }

            public void Imprimir()
            {
                Console.WriteLine("");
                for (int j = 0; j < 5; j++)
                {
                    if (edades[j] >= 18)
                    {
                        
                        Console.WriteLine(nombres[j]+ " es mayor de edad");
                    }
                    else
                    {
                        
                    }
                }
                Console.ReadKey();
            }

        }

    }
}
